Student Numbers
===============================
1669326
1846346
===============================

How to Run
===============================
K-Means
Enter KMeans Folder

Change Jobscript to output to correct account.

Type make
Submit the jobscript file for serial, CUDA, and Open MPI
View output


Fuzzy C-Means:
Enter FuzzyMeans Folder

Change Jobscript to output to correct account.

Type make
Submit the jobscript file for serial, CUDA, and Open MPI
View output


===============================================================
How to change variables for kmeans or fuzzymeans respectively
================================================================
DIMENSIONS can be changed in point.h or fuzzyPoint.h
NUMCLUSTER can be changed in point.h or fuzzyPoint.h
NUMPOINTS can be changed in KMeans.h or fuzzyMeans.h